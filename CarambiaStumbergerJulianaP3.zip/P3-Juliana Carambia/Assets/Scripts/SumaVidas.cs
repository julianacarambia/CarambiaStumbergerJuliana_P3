using UnityEngine;
using System.Collections;

public class SumaVidas : MonoBehaviour
{

	public GameObject VidasGO;
	public Vidas vidasScript;

	void Start()
	{
		VidasGO = GameObject.Find("Vidas");
		vidasScript = VidasGO.GetComponent<Vidas>();
	}

	void OnTriggerEnter2D(Collider2D cInfo)
	{
		if (cInfo.gameObject.tag == "Idle")
		{
			if (vidasScript.contadorVidas < 3)
			{
				vidasScript.contadorVidas = vidasScript.contadorVidas + 1;
				vidasScript.ImagenMasVida();
			}
			gameObject.SetActive(false);
		}
	}

}
