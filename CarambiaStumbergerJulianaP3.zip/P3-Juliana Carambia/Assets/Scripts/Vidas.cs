using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Vidas : MonoBehaviour
{
    public GameObject[] vidas;
    public int contadorVidas = 3;
    public GameObject popGameOverGO;
    public PopGameOver popGameOverScript;
    public MotorCarreteras motorCarreterasScript;
    public Image menosVida;
	public Image sumaVidas;

	// Start is called before the first frame update
	void Start()
    {
        menosVida.CrossFadeAlpha(0, 0, false);
		sumaVidas.CrossFadeAlpha(0, 0, false);
	}

	// Update is called once per frame
	void Update()
	{
		if (contadorVidas == 3 && motorCarreterasScript.juegoTerminado==false)
		{
			vidas[2].SetActive(true);
		}
		if (contadorVidas == 2 && motorCarreterasScript.juegoTerminado == false)
		{
			vidas[2].SetActive(false);
			vidas[1].SetActive(true);
			vidas[0].SetActive(true);
		}
		if (contadorVidas == 1 && motorCarreterasScript.juegoTerminado == false)
		{
			vidas[1].SetActive(false);
			vidas[0].SetActive(true);
		}
		if (contadorVidas == 0 && motorCarreterasScript.juegoTerminado == false)
		{
			vidas[0].SetActive(false);
			motorCarreterasScript.juegoTerminado = true;
			popGameOverGO.SetActive(true);
			popGameOverScript.ActivoGameOver();
		}

	}
	public void ImagenMenosVida()
	{
		if (contadorVidas >= 1)
		{
			menosVida.CrossFadeAlpha(1, 0.5f, false);
			this.gameObject.GetComponent<AudioSource>().Play();
			StartCoroutine(CierroImagenMenosVida());
		}
	}

	IEnumerator CierroImagenMenosVida()
	{
		yield return new WaitForSeconds(1);
		menosVida.CrossFadeAlpha(0, 0.5f, false);

	}
	public void ImagenMasVida()
	{
		if (contadorVidas >= 1)
		{
			sumaVidas.CrossFadeAlpha(1, 0.5f, false);
			this.gameObject.GetComponent<AudioSource>().Play();
			StartCoroutine(CierroImagenSumaVidas());
		}
	}

	IEnumerator CierroImagenSumaVidas()
	{
		yield return new WaitForSeconds(1);
		sumaVidas.CrossFadeAlpha(0, 0.5f, false);

	}
}
