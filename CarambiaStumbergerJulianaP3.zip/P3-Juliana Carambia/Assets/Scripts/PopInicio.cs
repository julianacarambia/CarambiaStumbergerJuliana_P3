using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PopInicio : MonoBehaviour
{
    public GameObject popInicioGO;
    public bool inicio = false;
    void Start()
    {
        popInicioGO.SetActive(true);
        Time.timeScale = 0f;
    }
    public void CierroPop()
    { 
        popInicioGO.SetActive(false);
        Time.timeScale = 1f;
    }



}
