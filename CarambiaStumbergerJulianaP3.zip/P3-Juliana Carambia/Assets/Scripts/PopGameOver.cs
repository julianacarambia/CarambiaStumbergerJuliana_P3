using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PopGameOver : MonoBehaviour
{

	public Image BGpop;
	public Image imgPop;
	public Button botonReiniciar;
	public Text metrosRecorridos;
	public GameObject popGameOverGO;
	public Image imagenFundido;
	public GameObject Idle;
	public Metros metrosScript;


	// Use this for initialization
	void Start()
	{

		popGameOverGO.SetActive(false);
		metrosRecorridos = GetComponent<Text>();

	}
	
	public void ActivoGameOver()
	{
		Time.timeScale = 0f;
		botonReiniciar.gameObject.SetActive(true);
		BGpop.CrossFadeAlpha(1, 0.3f, false);
		imgPop.CrossFadeAlpha(1, 0.3f, false);
		metrosRecorridos.CrossFadeAlpha(1, 0.3f, false);
		metrosRecorridos.text = "Has recorrido " + metrosScript.contador + " mts";
	}

	public void ReiniciarJuego()
	{
		imagenFundido.CrossFadeAlpha(1, 0.5f, false);
		StartCoroutine(CargoEscena());
	}

	IEnumerator CargoEscena()
	{
		yield return new WaitForSeconds(1);
		Application.LoadLevel("Scene");

	}
}



