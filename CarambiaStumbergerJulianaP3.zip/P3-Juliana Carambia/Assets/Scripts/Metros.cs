using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Metros : MonoBehaviour
{
    public GameObject motorCarreteras;
    public MotorCarreteras motorCarreterasScript;
    public string contador;
    public Text textoMetros;

    public float distancia;

    // Start is called before the first frame update
    void Start()
    {
        textoMetros = GetComponent<Text>();
        textoMetros.text = "0";
    }

    // Update is called once per frame
    void Update()
    {
        if (motorCarreterasScript.juegoTerminado==false)
        {
            distancia += Time.deltaTime * motorCarreterasScript.speed;
            contador = ((int)distancia).ToString();
            textoMetros.text = contador;

        }



    }
}
