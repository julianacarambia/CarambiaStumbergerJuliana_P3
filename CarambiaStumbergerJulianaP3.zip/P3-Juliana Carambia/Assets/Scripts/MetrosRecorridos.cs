using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MetrosRecorridos : MonoBehaviour
{
    private Text elmeshi;
    public Metros metrosscript;

    // Start is called before the first frame update
    void Start()
    {
        elmeshi = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        elmeshi.text = metrosscript.textoMetros.text;
    }
}
