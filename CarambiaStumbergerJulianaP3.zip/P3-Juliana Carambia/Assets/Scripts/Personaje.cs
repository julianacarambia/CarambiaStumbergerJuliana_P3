using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Personaje : MonoBehaviour
{
    public GameObject jugador;
    public Rigidbody2D rigidbody2D;
    public float velocidad = 3f;
    public BoxCollider2D boxcollider2D;

    // Start is called before the first frame update
    void Start()
    {
        rigidbody2D = GetComponent<Rigidbody2D>();
        boxcollider2D = GetComponent<BoxCollider2D>();
    }

    // Update is called once per frame
    void Update()
    {
        float eje_x = Input.GetAxis("Horizontal");
        Vector2 mov_x = jugador.transform.right * velocidad * Time.deltaTime;
        if (eje_x > 0.0f)
        {
            rigidbody2D.transform.Translate(mov_x);
        }
        if (eje_x < 0.0f)
        {
            rigidbody2D.transform.Translate(-mov_x);
        }
    }
}

